﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lesson8
{
    internal class Furinter
    {
        KindFuruneter KindFuruneter { get; set; }
        public int Color { get; set; }
        public bool Oldornew { get; set; }
    }
}
